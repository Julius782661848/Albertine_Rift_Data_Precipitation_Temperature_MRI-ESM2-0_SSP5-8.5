The following commands were used to create the files in this container:

cdo -s outputtab,date,value,nohead -fldmean -sellonlatbox,29.000000,31.500000,-2.000000,2.000000 mri-esm2-0_r1i1p1f1_w5e5_ssp585_tas_global_daily_2015_2020.nc
cdo -s outputtab,date,value,nohead -fldmean -sellonlatbox,29.000000,31.500000,-2.000000,2.000000 mri-esm2-0_r1i1p1f1_w5e5_ssp585_tas_global_daily_2021_2030.nc
cdo -s outputtab,date,value,nohead -fldmean -sellonlatbox,29.000000,31.500000,-2.000000,2.000000 mri-esm2-0_r1i1p1f1_w5e5_ssp585_tas_global_daily_2031_2040.nc
cdo -s outputtab,date,value,nohead -fldmean -sellonlatbox,29.000000,31.500000,-2.000000,2.000000 mri-esm2-0_r1i1p1f1_w5e5_ssp585_tas_global_daily_2041_2050.nc
